package com.odin.gregtechskilltree;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Installs the bundled FTB Quests skill tree into config/ftbquests/quests.
 * It runs once per bundle version, and backs up any file it replaces first.
 */
@Mod(GregTechSkillTree.MOD_ID)
public final class GregTechSkillTree {
    public static final String MOD_ID = "gregtech_skill_tree";
    private static final Logger LOGGER = LogUtils.getLogger();

    /** Bump this whenever the bundled quest files change; the installer re-runs when it differs. */
    private static final String VERSION = "1.0.4";
    private static final String ROOT = "quest_bundle/config/ftbquests/quests/";
    private static final String MARKER = "gregtech_skill_tree.version";

    private static final String[] FILES = {
            "chapter_groups.snbt",
            "chapters/gtceu.snbt",
            "chapters/heating_coils.snbt",
            "chapters/hv__high_voltage.snbt",
            "chapters/iv__insane_voltage.snbt",
            "chapters/luv__ludicrous_voltage.snbt",
            "chapters/lv__low_voltage.snbt",
            "chapters/mv__medium_voltage.snbt",
            "chapters/progression.snbt",
            "chapters/renewability_and_you.snbt",
            "chapters/uv__ultimate_voltage.snbt",
            "data.snbt",
            "reward_tables/bronze_age.snbt",
            "reward_tables/hv_components.snbt",
            "reward_tables/polyethylene.snbt",
            "reward_tables/titanium.snbt"
    };

    public GregTechSkillTree() {
        installQuestFiles();
    }

    private static void installQuestFiles() {
        try {
            Path quests = FMLPaths.CONFIGDIR.get().resolve("ftbquests").resolve("quests");
            Files.createDirectories(quests);

            Path marker = quests.resolve(MARKER);
            if (Files.exists(marker) && VERSION.equals(Files.readString(marker, StandardCharsets.UTF_8).trim())) {
                return; // already installed; leave the player's files alone
            }

            Path backup = quests.getParent().resolve("quests-backup-gregtech-skill-tree-" + System.currentTimeMillis());
            int backedUp = 0;
            for (String file : FILES) {
                Path target = quests.resolve(file);
                if (Files.exists(target)) {
                    Path saved = backup.resolve(file);
                    Files.createDirectories(saved.getParent());
                    Files.copy(target, saved, StandardCopyOption.REPLACE_EXISTING);
                    backedUp++;
                }
                copyResource(ROOT + file, target);
            }
            Files.writeString(marker, VERSION, StandardCharsets.UTF_8);
            LOGGER.info("[GregTech Skill Tree] Installed quest files (v{}). Backed up {} existing file(s) to {}",
                    VERSION, backedUp, backedUp > 0 ? backup : "(nothing to back up)");
        } catch (Exception e) {
            LOGGER.error("[GregTech Skill Tree] Failed to install quest files", e);
        }
    }

    private static void copyResource(String resource, Path target) throws IOException {
        try (InputStream in = GregTechSkillTree.class.getClassLoader().getResourceAsStream(resource)) {
            if (in == null) throw new FileNotFoundException("Missing bundled resource " + resource);
            Files.createDirectories(target.getParent());
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
