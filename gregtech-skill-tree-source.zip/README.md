# GregTech Skill Tree (Forge 1.20.1) - v1.0.4
Requires FTB Quests, FTB Filter System, FTB XMod Compat and GregTech CEu Modern.
Build with `gradle build` (JDK 17, Gradle 8.1.1) or push to GitHub and use the "build" action.
On first launch the mod installs its quests into `config/ftbquests/quests` and backs up replaced files.
