# GregTech Field Guide (Forge 1.20.1)
Build: install JDK 17, run `gradle wrapper` once (or open in IntelliJ), then `./gradlew build`.
The jar lands in `build/libs/`. Set `authors` in `src/main/resources/META-INF/mods.toml` first.
