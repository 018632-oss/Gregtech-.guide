package com.example.gtguide;

import net.minecraft.client.Minecraft;

public final class ClientHooks {
    private ClientHooks() {}

    public static void openQuestScreen() {
        Minecraft.getInstance().setScreen(new QuestScreen());
    }
}
