package com.example.gtguide;

import com.example.gtguide.MultiblockData.Multiblock;
import com.example.gtguide.MultiblockData.Part;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Rotatable 3D preview of a multiblock, with a layer slider, built from item models (so it needs no world). */
public class MultiblockScreen extends Screen {
    private static final int LEGEND_W = 210;

    private final Screen parent;
    private final Multiblock mb;
    private final Map<Character, ItemStack> main = new HashMap<>();
    private final Map<Character, ItemStack> fallback = new HashMap<>();
    private final Map<Character, Integer> counts = new HashMap<>();
    private final Set<Character> standIn = new HashSet<>();

    private float yaw = -30f;
    private float pitch = 25f;
    private float zoom = 1f;
    private boolean spin = true;
    private boolean dragging = false;
    private int shownLayers;
    private Button spinButton;

    public MultiblockScreen(Screen parent, Multiblock mb) {
        super(Component.literal(mb.name()));
        this.parent = parent;
        this.mb = mb;
        this.shownLayers = mb.sizeY();
        for (Part p : mb.parts().values()) {
            ItemStack fb = stackOf(p.fallback(), null);
            ItemStack primary = stackOf(p.item(), fb);
            if (primary == fb) standIn.add(p.key());
            main.put(p.key(), primary);
            fallback.put(p.key(), fb);
        }
        for (String[] layer : mb.layers()) {
            for (String row : layer) {
                for (char c : row.toCharArray()) {
                    if (c != ' ' && mb.parts().containsKey(c)) counts.merge(c, 1, Integer::sum);
                }
            }
        }
    }

    private static ItemStack stackOf(String id, ItemStack orElse) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        Item item = rl == null ? null : ForgeRegistries.ITEMS.getValue(rl);
        if (item == null || item == Items.AIR) {
            return orElse != null ? orElse : new ItemStack(Items.BARRIER);
        }
        return new ItemStack(item);
    }

    @Override
    protected void init() {
        int y = height - 28;
        addRenderableWidget(Button.builder(Component.literal("Layer -"), b -> shownLayers = Math.max(1, shownLayers - 1))
                .bounds(10, y, 60, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Layer +"), b -> shownLayers = Math.min(mb.sizeY(), shownLayers + 1))
                .bounds(74, y, 60, 20).build());
        spinButton = Button.builder(Component.literal("Spin: on"), b -> {
            spin = !spin;
            b.setMessage(Component.literal(spin ? "Spin: on" : "Spin: off"));
        }).bounds(138, y, 70, 20).build();
        addRenderableWidget(spinButton);
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
                .bounds(width - 70, y, 60, 20).build());
    }

    @Override
    public void tick() {
        if (spin && !dragging) yaw += 0.8f;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g);
        g.drawCenteredString(font, mb.name(), width / 2 + LEGEND_W / 2, 8, 0xFFFFFF);

        drawModel(g);

        // Legend
        int y = 24;
        for (Part p : mb.parts().values()) {
            ItemStack icon = standIn.contains(p.key()) ? fallback.get(p.key()) : main.get(p.key());
            g.renderItem(icon, 10, y);
            String label = p.name() + "  x" + counts.getOrDefault(p.key(), 0);
            g.drawString(font, label, 32, y + 4, 0xFFFFFF);
            if (standIn.contains(p.key())) {
                g.drawString(font, "(stand-in model)", 32, y + 14, 0x888888);
                y += 10;
            }
            y += 20;
        }
        y += 4;
        for (FormattedCharSequence line : font.split(Component.literal(mb.notes()), LEGEND_W - 20)) {
            if (y > height - 60) break;
            g.drawString(font, line, 10, y, 0xAAAAAA, false);
            y += 10;
        }
        g.drawString(font, "Layers shown: " + shownLayers + "/" + mb.sizeY(), 10, height - 42, 0xCCCCCC);
        g.drawString(font, "Drag to rotate, scroll to zoom", width - 190, 8, 0x888888);

        super.render(g, mx, my, partial);
    }

    private void drawModel(GuiGraphics g) {
        int sx = mb.sizeX();
        int sy = mb.sizeY();
        int sz = mb.sizeZ();
        double diag = Math.sqrt(sx * sx + sy * sy + sz * sz);
        float area = Math.min(width - LEGEND_W - 20, height - 70);
        float scale = (float) (area / diag) * zoom;

        PoseStack pose = g.pose();
        pose.pushPose();
        pose.translate(LEGEND_W + (width - LEGEND_W) / 2f, height / 2f - 10, 200);
        pose.scale(scale, -scale, scale);
        pose.mulPose(Axis.XP.rotationDegrees(pitch));
        pose.mulPose(Axis.YP.rotationDegrees(yaw));
        pose.translate(-sx / 2f, -sy / 2f, -sz / 2f);

        RenderSystem.enableDepthTest();
        ItemRenderer ir = net.minecraft.client.Minecraft.getInstance().getItemRenderer();
        MultiBufferSource.BufferSource buf = g.bufferSource();

        for (int y = 0; y < Math.min(shownLayers, sy); y++) {
            String[] rows = mb.layers().get(y);
            for (int z = 0; z < rows.length; z++) {
                String row = rows[z];
                for (int x = 0; x < row.length(); x++) {
                    char c = row.charAt(x);
                    if (c == ' ' || !mb.parts().containsKey(c)) continue;
                    pose.pushPose();
                    pose.translate(x + 0.5, y + 0.5, z + 0.5);
                    drawBlock(ir, pose, buf, c);
                    pose.popPose();
                }
            }
        }
        g.flush();
        pose.popPose();
    }

    private void drawBlock(ItemRenderer ir, PoseStack pose, MultiBufferSource buf, char c) {
        ItemStack stack = standIn.contains(c) ? fallback.get(c) : main.get(c);
        try {
            BakedModel model = ir.getModel(stack, null, null, 0);
            ir.render(stack, ItemDisplayContext.NONE, false, pose, buf,
                    LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, model);
        } catch (Exception ex) {
            // Some modded blocks can't be drawn this way; fall back to the stand-in and stop retrying.
            standIn.add(c);
        }
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && mx > LEGEND_W && my < height - 34) {
            dragging = true;
            yaw += (float) dx * 0.8f;
            pitch = Mth.clamp(pitch + (float) dy * 0.6f, -85f, 85f);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        zoom = Mth.clamp(zoom + (float) delta * 0.1f, 0.4f, 2.5f);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (minecraft != null && minecraft.options.keyInventory.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        if (minecraft != null) minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
