package com.example.gtguide;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Loads the quest tree from assets/gregtechguide/quests/gregtech.json (editable, resource-pack overridable). */
public final class QuestData {
    private static final Logger LOGGER = LogUtils.getLogger();

    public record Quest(String id, String title, String desc, int x, int y, String icon,
                        String item, String tag, int count, boolean manual, String multiblock,
                        List<String> parents) {}

    private QuestData() {}

    public static List<Quest> load() {
        List<Quest> out = new ArrayList<>();
        try {
            Optional<Resource> res = Minecraft.getInstance().getResourceManager()
                    .getResource(new ResourceLocation(GregTechGuide.MOD_ID, "quests/gregtech.json"));
            if (res.isEmpty()) {
                LOGGER.error("Quest file quests/gregtech.json not found");
                return out;
            }
            try (Reader r = new BufferedReader(new InputStreamReader(res.get().open(), StandardCharsets.UTF_8))) {
                JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
                for (JsonElement e : root.getAsJsonArray("quests")) {
                    JsonObject o = e.getAsJsonObject();
                    String item = str(o, "item", null);
                    String tag = str(o, "tag", null);
                    boolean manual = (o.has("manual") && o.get("manual").getAsBoolean()) || (item == null && tag == null);
                    List<String> parents = new ArrayList<>();
                    if (o.has("parents")) {
                        JsonArray arr = o.getAsJsonArray("parents");
                        for (JsonElement p : arr) parents.add(p.getAsString());
                    }
                    out.add(new Quest(
                            str(o, "id", "?"), str(o, "title", "?"), str(o, "desc", ""),
                            o.has("x") ? o.get("x").getAsInt() : 0,
                            o.has("y") ? o.get("y").getAsInt() : 0,
                            str(o, "icon", "minecraft:book"), item, tag,
                            o.has("count") ? o.get("count").getAsInt() : 1,
                            manual, str(o, "multiblock", null), parents));
                }
            }
        } catch (Exception ex) {
            LOGGER.error("Failed to load quest tree", ex);
        }
        return out;
    }

    private static String str(JsonObject o, String key, String def) {
        return o.has(key) ? o.get(key).getAsString() : def;
    }
}
