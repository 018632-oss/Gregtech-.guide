package com.example.gtguide;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import org.slf4j.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Loads a multiblock layout from assets/gregtechguide/multiblocks/<id>.json. */
public final class MultiblockData {
    private static final Logger LOGGER = LogUtils.getLogger();

    /** One legend entry: the character used in the layout, display name, item to draw, and a vanilla stand-in. */
    public record Part(char key, String name, String item, String fallback) {}

    /** layers are bottom to top; each layer is a list of rows from back to front; ' ' is empty space. */
    public record Multiblock(String name, Map<Character, Part> parts, List<String[]> layers, String notes) {
        public int sizeY() { return layers.size(); }

        public int sizeZ() {
            int n = 0;
            for (String[] l : layers) n = Math.max(n, l.length);
            return n;
        }

        public int sizeX() {
            int n = 0;
            for (String[] l : layers) for (String row : l) n = Math.max(n, row.length());
            return n;
        }
    }

    private MultiblockData() {}

    public static Multiblock load(String id) {
        try {
            Optional<Resource> res = Minecraft.getInstance().getResourceManager()
                    .getResource(new ResourceLocation(GregTechGuide.MOD_ID, "multiblocks/" + id + ".json"));
            if (res.isEmpty()) {
                LOGGER.error("Multiblock file {} not found", id);
                return null;
            }
            try (Reader r = new BufferedReader(new InputStreamReader(res.get().open(), StandardCharsets.UTF_8))) {
                JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
                Map<Character, Part> parts = new LinkedHashMap<>();
                JsonObject legend = root.getAsJsonObject("legend");
                for (Map.Entry<String, JsonElement> e : legend.entrySet()) {
                    JsonObject o = e.getValue().getAsJsonObject();
                    char key = e.getKey().charAt(0);
                    parts.put(key, new Part(key,
                            o.get("name").getAsString(),
                            o.get("item").getAsString(),
                            o.has("fallback") ? o.get("fallback").getAsString() : "minecraft:stone"));
                }
                List<String[]> layers = new ArrayList<>();
                for (JsonElement layer : root.getAsJsonArray("layers")) {
                    List<String> rows = new ArrayList<>();
                    for (JsonElement row : layer.getAsJsonArray()) rows.add(row.getAsString());
                    layers.add(rows.toArray(new String[0]));
                }
                return new Multiblock(
                        root.has("name") ? root.get("name").getAsString() : id,
                        parts, layers,
                        root.has("notes") ? root.get("notes").getAsString() : "");
            }
        } catch (Exception ex) {
            LOGGER.error("Failed to load multiblock " + id, ex);
            return null;
        }
    }
}
