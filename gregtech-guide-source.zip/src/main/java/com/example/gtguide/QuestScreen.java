package com.example.gtguide;

import com.example.gtguide.QuestData.Quest;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestScreen extends Screen {
    private static final int NODE = 26;
    private static final int GAP = 52;
    private static final int PANEL_H = 104;

    private final List<Quest> quests;
    private final Map<String, Quest> byId = new HashMap<>();
    private final Map<String, ItemStack> icons = new HashMap<>();
    private double offX;
    private double offY;
    private Quest selected;
    private Button toggle;
    private Button viewButton;
    private boolean placed;

    public QuestScreen() {
        super(Component.literal("GregTech Quests"));
        QuestProgress.load();
        this.quests = QuestData.load();
        for (Quest q : quests) {
            byId.put(q.id(), q);
            icons.put(q.id(), stackOf(q.icon()));
        }
    }

    private static ItemStack stackOf(String id) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        Item item = rl == null ? Items.AIR : ForgeRegistries.ITEMS.getValue(rl);
        return new ItemStack(item == null || item == Items.AIR ? Items.BARRIER : item);
    }

    @Override
    protected void init() {
        if (!placed) {
            offX = 40;
            offY = (height - PANEL_H) / 2.0 - NODE / 2.0;
            placed = true;
        }
        toggle = Button.builder(Component.literal("Mark complete"), b -> {
            if (selected != null && isUnlocked(selected)) {
                QuestProgress.setDone(selected.id(), !QuestProgress.isDone(selected.id()));
            }
        }).bounds(width - 130, height - 28, 120, 20).build();
        toggle.visible = false;
        addRenderableWidget(toggle);
        viewButton = Button.builder(Component.literal("View 3D model"), b -> {
            if (selected != null && selected.multiblock() != null) {
                MultiblockData.Multiblock mb = MultiblockData.load(selected.multiblock());
                if (mb != null) Minecraft.getInstance().setScreen(new MultiblockScreen(this, mb));
            }
        }).bounds(width - 130, height - 52, 120, 20).build();
        viewButton.visible = false;
        addRenderableWidget(viewButton);
    }

    private boolean isUnlocked(Quest q) {
        for (String p : q.parents()) {
            if (byId.containsKey(p) && !QuestProgress.isDone(p)) return false;
        }
        return true;
    }

    private boolean matches(Quest q, ItemStack s) {
        if (s.isEmpty()) return false;
        if (q.tag() != null) {
            ResourceLocation rl = ResourceLocation.tryParse(q.tag());
            return rl != null && s.is(ItemTags.create(rl));
        }
        ResourceLocation rl = ResourceLocation.tryParse(q.item());
        return rl != null && ForgeRegistries.ITEMS.getValue(rl) == s.getItem();
    }

    private boolean hasItems(Quest q) {
        Player p = Minecraft.getInstance().player;
        if (p == null) return false;
        int n = 0;
        for (ItemStack s : p.getInventory().items) {
            if (matches(q, s)) n += s.getCount();
        }
        return n >= q.count();
    }

    @Override
    public void tick() {
        // The list is ordered parents-first, so a whole chain can complete in one pass.
        for (Quest q : quests) {
            if (!q.manual() && !QuestProgress.isDone(q.id()) && isUnlocked(q) && hasItems(q)) {
                QuestProgress.setDone(q.id(), true);
            }
        }
    }

    private int nodeX(Quest q) {
        return (int) (offX + q.x() * GAP);
    }

    private int nodeY(Quest q) {
        return (int) (offY + q.y() * GAP);
    }

    private Quest nodeAt(double mx, double my) {
        for (Quest q : quests) {
            int sx = nodeX(q);
            int sy = nodeY(q);
            if (mx >= sx && mx <= sx + NODE && my >= sy && my <= sy + NODE) return q;
        }
        return null;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g);
        int areaBottom = height - PANEL_H;

        g.enableScissor(0, 0, width, areaBottom);
        for (Quest q : quests) {
            for (String pid : q.parents()) {
                Quest p = byId.get(pid);
                if (p == null) continue;
                int x1 = nodeX(p) + NODE;
                int y1 = nodeY(p) + NODE / 2;
                int x2 = nodeX(q);
                int y2 = nodeY(q) + NODE / 2;
                int mid = (x1 + x2) / 2;
                int color = QuestProgress.isDone(pid) ? 0xFF3CB043 : 0xFF666666;
                g.hLine(Math.min(x1, mid), Math.max(x1, mid), y1, color);
                g.vLine(mid, Math.min(y1, y2), Math.max(y1, y2), color);
                g.hLine(Math.min(mid, x2), Math.max(mid, x2), y2, color);
            }
        }
        for (Quest q : quests) {
            int sx = nodeX(q);
            int sy = nodeY(q);
            boolean done = QuestProgress.isDone(q.id());
            boolean unlocked = isUnlocked(q);
            int border = done ? 0xFF3CB043 : (unlocked ? 0xFFE0C040 : 0xFF555555);
            if (q == selected) border = 0xFFFFFFFF;
            g.fill(sx - 2, sy - 2, sx + NODE + 2, sy + NODE + 2, border);
            g.fill(sx, sy, sx + NODE, sy + NODE, done ? 0xFF1E3A1E : 0xFF202024);
            g.renderItem(icons.get(q.id()), sx + 5, sy + 5);
            if (!unlocked) g.fill(sx, sy, sx + NODE, sy + NODE, 0xAA000000);
        }
        g.disableScissor();

        g.fill(0, areaBottom, width, height, 0xE0101010);
        g.hLine(0, width, areaBottom, 0xFF888888);
        g.drawString(font, "GregTech Field Guide  -  drag to pan, click a quest  (" +
                QuestProgress.doneCount() + "/" + quests.size() + ")", 8, 6, 0xFFFFFF);
        if (quests.isEmpty()) {
            g.drawString(font, "Quest data failed to load - see the game log.", 8, 20, 0xFF5555);
        }

        if (selected != null) {
            boolean done = QuestProgress.isDone(selected.id());
            boolean unlocked = isUnlocked(selected);
            g.drawString(font, selected.title(), 10, areaBottom + 8, 0xFFFFFF);
            String status = done ? "Completed" : (unlocked ? "Available" : "Locked - finish the previous quests first");
            int statusColor = done ? 0x55FF55 : (unlocked ? 0xFFFF55 : 0xAAAAAA);
            g.drawString(font, status, 10, areaBottom + 20, statusColor);
            int y = areaBottom + 34;
            for (FormattedCharSequence line : font.split(Component.literal(selected.desc()), width - 150)) {
                if (y > height - 10) break;
                g.drawString(font, line, 10, y, 0xCCCCCC, false);
                y += 10;
            }
            toggle.visible = unlocked;
            viewButton.visible = selected.multiblock() != null;
            toggle.setMessage(Component.literal(done ? "Undo completion" : "Mark complete"));
            if (!selected.manual()) {
                String req = selected.tag() != null ? "#" + selected.tag()
                        : new ItemStack(ForgeRegistries.ITEMS.getValue(ResourceLocation.tryParse(selected.item()))).getHoverName().getString();
                g.drawString(font, "Auto: carry " + selected.count() + "x " + req, width - 240, areaBottom + 8, 0x88CCFF);
            }
        } else {
            toggle.visible = false;
            viewButton.visible = false;
        }

        super.render(g, mx, my, partial);

        if (my < areaBottom) {
            Quest hover = nodeAt(mx, my);
            if (hover != null) g.renderTooltip(font, Component.literal(hover.title()), mx, my);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (button == 0 && my < height - PANEL_H) {
            Quest hit = nodeAt(mx, my);
            if (hit != null) {
                selected = hit;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && my < height - PANEL_H) {
            offX += dx;
            offY += dy;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (minecraft != null && minecraft.options.keyInventory.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
