package com.example.gtguide;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

/** Client-side progress, saved to config/gregtechguide_progress.json (shared across worlds). */
public final class QuestProgress {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Set<String> DONE = new HashSet<>();

    private QuestProgress() {}

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("gregtechguide_progress.json");
    }

    public static void load() {
        DONE.clear();
        Path f = file();
        if (!Files.exists(f)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
            for (JsonElement e : root.getAsJsonArray("completed")) DONE.add(e.getAsString());
        } catch (Exception ex) {
            LOGGER.error("Failed to read quest progress", ex);
        }
    }

    public static boolean isDone(String id) {
        return DONE.contains(id);
    }

    public static int doneCount() {
        return DONE.size();
    }

    public static void setDone(String id, boolean done) {
        boolean changed = done ? DONE.add(id) : DONE.remove(id);
        if (changed) save();
    }

    private static void save() {
        try {
            JsonArray arr = new JsonArray();
            for (String id : DONE) arr.add(id);
            JsonObject root = new JsonObject();
            root.add("completed", arr);
            Files.writeString(file(), root.toString(), StandardCharsets.UTF_8);
        } catch (Exception ex) {
            LOGGER.error("Failed to save quest progress", ex);
        }
    }
}
